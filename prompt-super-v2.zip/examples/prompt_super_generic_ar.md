# Prompt Super – العربية الفصحى

<!-- Placeholder for the full العربية الفصحى translation of the prompt_super_generic.md. Replace this comment with the translated prompt. -->
