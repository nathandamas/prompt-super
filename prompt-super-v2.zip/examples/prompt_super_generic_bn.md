# Prompt Super – বাংলা (Bengali)

<!-- Placeholder for the full বাংলা (Bengali) translation of the prompt_super_generic.md. Replace this comment with the translated prompt. -->
