
<!-- Example: Filled prompt for a Biology article -->
⚙️[[TÍTULO_PROVISÓRIO]] = Comparative Transcriptomics in Marine Algae
⚙️[[ÁREA_DO_CONHECIMENTO]] = Marine Biology / Genomics
...
