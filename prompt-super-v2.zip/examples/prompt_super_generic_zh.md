# Prompt Super – 简体中文 (Mandarin)

<!-- Placeholder for the full 简体中文 (Mandarin) translation of the prompt_super_generic.md. Replace this comment with the translated prompt. -->
