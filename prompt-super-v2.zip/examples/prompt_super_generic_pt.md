# Prompt Super – Português

<!-- Placeholder for the full Português translation of the prompt_super_generic.md. Replace this comment with the translated prompt. -->
