
<!-- Example: Filled prompt for a Civil Engineering article -->
⚙️[[TÍTULO_PROVISÓRIO]] = Seismic Resilience of Bamboo‑Reinforced Concrete
⚙️[[ÁREA_DO_CONHECIMENTO]] = Structural Engineering
...
