
# Contributor Covenant Code of Conduct

This project follows the [Contributor Covenant](https://www.contributor-covenant.org/)
v2.1. By participating, you are expected to uphold this code. Please report
unacceptable behaviour to **<maintainer‑email>**.
