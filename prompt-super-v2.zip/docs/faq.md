## FAQ

**Q:** How do I replace placeholders?
**A:** Use generate_prompt.py or manual editing.