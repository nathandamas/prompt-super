
# Changelog
All notable changes to this project will be documented in this file.

## [1.0.0] - 2025-04-18
### Added
- Initial release of Prompt Super generic template.
