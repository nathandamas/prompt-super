| Section | Estimated words | Notes |
|---------|-----------------|-------|
