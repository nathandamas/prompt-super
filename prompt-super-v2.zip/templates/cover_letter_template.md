
Dear Editor,

Please find enclosed our manuscript entitled "⚙️[[Title]]". We believe it
fits the scope of ⚙️[[Journal]] because...

Sincerely,
⚙️[[Author Names]]
