
"""check_guidelines.py
Example stub that scans a PDF of journal guidelines and extracts numerical
limits (word count, refs, figures) using PyPDF2.
"""
print("TODO: implement PDF parsing.")
